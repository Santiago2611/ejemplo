package com.sena.DAO;
import com.sena.connection.Conexion;
import com.sena.models.Conductor;
import com.sena.models.Vehiculo;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class DAOConductor<conductor> extends Conexion{
    public void createConductor(Conductor c) {
        Connection conn = this.getConexion();
        String sql = "INSERT INTO conductor(nombre_completo,telefono,direccion,fecha_creacion) VALUES(?,?,?,now())";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getNombre_completo());
            ps.setString(2, c.getTelefono());
            ps.setString(3, c.getDireccion());
            System.out.println(ps.toString());
            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public Conductor searchConductor(int id) {
        Conductor cond = new Conductor();
        try {
            Connection conn = this.getConexion();
            String sql = "SELECT * FROM CONDUCTOR WHERE ID = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                cond.setNombre_completo(rs.getString("nombre_completo"));
                cond.setTelefono(rs.getString("telefono"));
                cond.setDireccion(rs.getString("direccion"));
                cond.setFecha_creacion(rs.getDate("fecha_creacion"));
            } else {
                System.out.println("El conductor no se encuentra en la base de datos");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return cond;
    }
    public ArrayList<Conductor> listConductors(){
        ArrayList<Conductor> conductores = new ArrayList<Conductor>();

        try {
            Connection conn = this.getConexion();
            String sql = "SELECT * FROM CONDUCTOR ";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Conductor cond = new Conductor();
                cond.setId(rs.getInt("id"));
                cond.setNombre_completo(rs.getString("nombre_completo"));
                cond.setTelefono(rs.getString("telefono"));
                cond.setDireccion(rs.getString("direccion"));
                cond.setFecha_creacion(rs.getDate("fecha_creacion"));
                conductores.add(cond);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return conductores;
    }

    public void updateConductor(Conductor c) {
        Connection conn = this.getConexion();
        String sql = "UPDATE conductor SET nombre_completo = ?, telefono = ?, direccion = ?" +
                " WHERE id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getNombre_completo());
            ps.setString(2, c.getTelefono());
            ps.setString(3, c.getDireccion());
            ps.setInt(4, c.getId());
            System.out.println(ps.toString());
            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void deleteConductor(Conductor c) {
        Connection conn = this.getConexion();
        String sql = "DELETE FROM conductor WHERE id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, c.getId());
            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
