package com.sena.DAO;

import com.sena.connection.Conexion;
import com.sena.models.Vehiculo;
import java.sql.*;

public class DAOVehiculo extends Conexion {

    public void createVehiculo(Vehiculo v) {
        Connection conn = this.getConexion();
        String sql = "INSERT INTO tbl_vehiculo(placa,modelo,marca,valorcomercial) VALUES(?,?,?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, v.getPlaca());
            ps.setString(2, v.getModelo());
            ps.setString(3, v.getMarca());
            ps.setDouble(4, v.getValorComercial());
            System.out.println(ps.toString());
            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void mostrarRegistros(java.awt.event.ActionEvent evt){
        String [] resultados = new String[2];
    }

    public Vehiculo searchVehiculo(String placa) {
        return null;
    }

    public void updateVehiculo(Vehiculo v) {
        Connection conn = this.getConexion();
        String sql = "UPDATE tbl_vehiculo SET placa = ?, modelo = ?, marca = ?, valorcomercial = ?" +
                " WHERE id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, v.getPlaca());
            ps.setString(2, v.getModelo());
            ps.setString(3, v.getMarca());
            ps.setDouble(4, v.getValorComercial());
            ps.setInt(5, v.getId());
            System.out.println(ps.toString());
            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void deleteVehiculo(int id) {
        Connection conn = this.getConexion();
        String sql = "DELETE FROM tbl_vehiculo WHERE id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
