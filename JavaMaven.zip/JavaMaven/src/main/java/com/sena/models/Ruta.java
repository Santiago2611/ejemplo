package com.sena.models;

public class Ruta {

    private int id;
    private String origen;
    private String destino;
    private double valor;
    private String ticket;

}
