package com.sena;

import com.sena.DAO.DAOConductor;
import com.sena.DAO.DAOVehiculo;
import com.sena.models.Conductor;
import com.sena.models.Vehiculo;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

//AUTOR: Mateo Zapata, ADSI 2252327
public class Main {

    public static void main(String[] args) throws SQLException {

        Scanner sc = new Scanner(System.in);
        DAOVehiculo dao = new DAOVehiculo();
        DAOConductor dao1 = new DAOConductor();

        Vehiculo vhc = new Vehiculo();

        System.out.println("¿Insertar vehículo (1), Actualizar (2), Eliminar (3), Crear conductor (4), Consultar conductor (5), Actualizar conductor (6), o eliminar (7)?");
        int decision = sc.nextInt();

        switch (decision) {
            case 1:
                for (int i = 1; i <= 3; i++) { // insertando
                    System.out.println("\n***INGRESANDO EL VEHÍCULO " + i + "***");
                    System.out.print("Placa del vehículo: ");
                    vhc.setPlaca(sc.next());
                    System.out.print("Modelo del vehículo: ");
                    vhc.setModelo(sc.next());
                    System.out.print("Marca del vehículo: ");
                    vhc.setMarca(sc.next());
                    System.out.print("Valor comercial del vehículo: ");
                    vhc.setValorComercial(sc.nextDouble());
                    dao.createVehiculo(vhc); // crea el vehículo
                }
                break;
            case 2:
                // actualizando
                Vehiculo updateVhc = new Vehiculo();
                System.out.println("Ingrese el ID del vehículo a actualizar...");
                updateVhc.setId(sc.nextInt());
                System.out.print("Placa del vehículo: ");
                updateVhc.setPlaca(sc.next());
                System.out.print("Modelo del vehículo: ");
                updateVhc.setModelo(sc.next());
                System.out.print("Marca del vehículo: ");
                updateVhc.setMarca(sc.next());
                System.out.print("Valor comercial del vehículo: ");
                updateVhc.setValorComercial(sc.nextDouble());
                dao.updateVehiculo(updateVhc);
                break;
            case 3:
                System.out.println("Ingrese el ID del vehículo a eliminar...");
                dao.deleteVehiculo(sc.nextInt());
            default:
                System.out.println("Opción no válida");
                break;
            case 4:
                Conductor conductor = new Conductor();
                System.out.println("\n***INGRESA LOS DATOS ****");
                System.out.print("Nombre del conductor: ");
                conductor.setNombre_completo(sc.next());
                System.out.print("Telefono del conductor: ");
                conductor.setTelefono(sc.next());
                System.out.print("Dirección del conductor: ");
                conductor.setDireccion(sc.next());

                dao1.createConductor(conductor); // crea el vehículo
                break;
            case 5:
                Conductor conductor1 = new Conductor();
                System.out.println("\n ***INGRESA LOS DATOS ***");
                System.out.println("Ingresa el id del conductor: ");
                int id = sc.nextInt();
                dao1.searchConductor(id);
                break;
            case 6:
                Conductor conductor2 = new Conductor();
                System.out.println("Ingrese el ID del conductor a actualizar...");
                conductor2.setId(sc.nextInt());
                System.out.print("Nombre completo: ");
                conductor2.setNombre_completo(sc.next());
                System.out.print("Telefono: ");
                conductor2.setTelefono(sc.next());
                System.out.print("Direccion: ");
                conductor2.setDireccion(sc.next());

                dao1.updateConductor(conductor2);
                break;
            case 7:
                Conductor conductor3 = new Conductor();
                System.out.println("Ingresa el Id del conductor que deseas eliminar");
                conductor3.setId(sc.nextInt());
                dao1.deleteConductor(conductor3);

        }

    }

}
